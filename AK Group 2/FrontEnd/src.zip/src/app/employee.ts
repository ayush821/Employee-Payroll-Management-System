export class Employee {
    constructor(public id:number,
        public firstname:string,
        public lastname:string,
        public role:string,
        public emailid:string,
        public dob: string,
        public gender: string){}
}
